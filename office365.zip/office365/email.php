<?php
$to = 'YOUREMAIL@EMAIL.COM';